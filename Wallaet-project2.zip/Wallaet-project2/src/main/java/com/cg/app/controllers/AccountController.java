package com.cg.app.controllers;

import org.hibernate.annotations.ColumnTransformer;
import org.hibernate.annotations.ColumnTransformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.app.entities.Account;
import com.cg.app.services.AccountService;

@RestController
@RequestMapping("/accounts")
public class AccountController {
	@Autowired
	private AccountService service;
	
	
	@GetMapping(value="/{mobileNo}")
	public Account getAccounts(@PathVariable String mobileNo)
	{
		System.out.println(mobileNo);
		return service.getAccounyByMobile(mobileNo);
		
	}
	
	@PostMapping(value="/create", consumes = {"application/json", "application/xml"})
	public ResponseEntity<String>create(@RequestBody Account ac)
	{
		System.out.println("Create Method");
		service.createAccount(ac);
		return new ResponseEntity<String>("Record Created Successfully...!",HttpStatus.CREATED);
		
	}
	
	@DeleteMapping(value="/delete/{mobileNo}")	
	public ResponseEntity<String> delete(@PathVariable String mobileNo){
		
		service.deleteAccount(mobileNo);
		return new ResponseEntity<String>("Deleted",HttpStatus.OK);
	}
	
	@PutMapping(value="/add")
	public ResponseEntity<String>add(@RequestParam Double amount,@RequestParam String mobileno){
		Account ac=service.getAccounyByMobile(mobileno);
		service.addMoney(amount, ac);
		return new ResponseEntity<String>("Money Added",HttpStatus.OK);
	}
	
	@PutMapping(value="/transfer/{amount}/{ac1}/{ac2}")	
	public ResponseEntity<String>transfer(@PathVariable Double amount,@PathVariable Account ac1,@PathVariable Account ac2)
	{
		service.transferMoney(amount, ac1, ac2);
		return  new ResponseEntity<String>("money successfully transfered",HttpStatus.OK);
	}
	@PutMapping(value="/withdraw/{amount}/{ac}")
	public ResponseEntity<String>withdraw(@PathVariable Double amount,@PathVariable Account ac){
		service.withdraw(amount, ac);
		return new ResponseEntity<String>("Money Withdrwan successfully",HttpStatus.OK);
	}


}

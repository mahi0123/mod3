package com.cg.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class WallaetProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(WallaetProjectApplication.class, args);
	}

}

package com.cg.app.services;

import java.util.List;
import java.util.Map;

import com.cg.app.entities.Account;

public interface AccountService {
	
void createAccount(Account ac);
void deleteAccount(String mobileNo);
Account getAccounyByMobile(String mobileNo);
void transferMoney(Double amount,Account ac1,Account ac2);
void addMoney(Double amount,Account ac);
List<Account>getAllAccounts();
void withdraw(Double amount,Account ac);



}

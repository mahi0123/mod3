package com.cg.app.services;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.app.dao.AccountDao;
import com.cg.app.entities.Account;

@Service
@Transactional // Enable Declarative transaction support
public class AccountServiceImpl implements AccountService {
	@Autowired private AccountDao dao;
	

	@Transactional
	public void createAccount(Account ac) {
		dao.save(ac);
		
	}
	
		


@Transactional
public void deleteAccount(String mobileNo) {

	dao.deleteById(mobileNo);
}
@Transactional
public Account getAccounyByMobile(String mobileNo) {

	return dao.findById(mobileNo).get();
	
}
@Transactional
public void addMoney(Double amount, Account ac) {
	Account a=getAccounyByMobile(ac.getMobileNo());
	if(a!=null) {
		
		Double am1=a.getBalance()+amount;
		a.setBalance(am1);
		dao.save(a);}
		else 
			dao.save(ac);}

@Transactional
public void transferMoney(Double amount, Account ac1, Account ac2) {
	double am=ac1.getBalance();
	am=am-amount;
	ac1.setBalance(am);
	double am1=ac2.getBalance();
	am1=am1+amount;
	ac2.setBalance(am1);
	dao.save(ac1);
	dao.save(ac2);
	
	
}




@Transactional
public List<Account> getAllAccounts() {

	return dao.findAll();
}



@Transactional
public void withdraw(Double amount, Account ac) {
double dm=ac.getBalance();
dm=dm-amount;
ac.setBalance(dm);
dao.save(ac);
	
}



}
	
	



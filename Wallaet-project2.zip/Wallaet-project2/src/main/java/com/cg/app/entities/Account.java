package com.cg.app.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="walletaccount")
@XmlRootElement
public class Account implements Serializable{
	

	@Id 
	@Column(name="mobileno",length=30)
	private String mobileNo;
	
	@Column(name="acctnumber",length=30)
	private Integer acctNumber;

	@Column(name="custname",length=30)
	private String custName;

	private Double balance;

	public Integer getAcctNumber() {
		return acctNumber;
	}
	public void setAcctNumber(Integer acctNumber) {
		this.acctNumber = acctNumber;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
/*	public Account() {
		// TODO Auto-generated constructor stub
	}
	public Account(Integer acctNumber, String mobileNo, String custName, Double balance) {
		super();
		this.acctNumber = acctNumber;
		this.mobileNo = mobileNo;
		this.custName = custName;
		this.balance = balance;
	}
	
*/
}

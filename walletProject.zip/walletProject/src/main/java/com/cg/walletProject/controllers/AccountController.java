package com.cg.walletProject.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.walletProject.entities.Account;
import com.cg.walletProject.services.AccountService;

@RestController
@RequestMapping("/accounts")
public class AccountController {

	
	@Autowired private AccountService service;
	
	//create
	//Test URl: http:localhost:8080//accounts/create
	@PostMapping(value= {"/create"}, consumes= {"application/json", "application/xml"})
	public ResponseEntity <String> create (@RequestBody Account ac)
	{
		System.out.println("create Account..!"+ac.getMobileno());
		service.create(ac);
		return new ResponseEntity<>("Record Created",HttpStatus.CREATED);
	}
	
	//Test URl: http:localhost:8080/accounts/mobileNo
	//getting
	@GetMapping(value= {"/{mobileno}"}, produces= {"application/json", "application/xml"})

	public Account search (@PathVariable String mobileno)
	{
		System.out.println("create Account..!"+mobileno);
		 return service.search(mobileno);
	}
	
	
	//Test URl: http:localhost:8080/accounts/delete
	//delete
	@DeleteMapping(value="/delete")
	 public ResponseEntity<String> delete (@RequestParam String mobileno){
		service.delete(mobileno);
		return new ResponseEntity<String>("record deleted",HttpStatus.OK);
		
	}
	
	@PutMapping(value="/addmoney/{amount}/{mobileno}")
	 public ResponseEntity<String> addMoney(@PathVariable Integer amount, @PathVariable String mobileno){
		service.addMoney(amount, mobileno);
		
		return new ResponseEntity<String>("Money Added", HttpStatus.OK);
		
	}
	@PutMapping(value="/withdraw/{amount}/{mobileno}")
	 public ResponseEntity<String> withDraw(@PathVariable Integer amount, @PathVariable String mobileno){
		service.WithDraw(mobileno, amount);
		
		return new ResponseEntity<String>("Money WithDrawn", HttpStatus.OK);
		
	}
	@PutMapping(value="/transfer/{amount}/{mobileno1}/{mobileno2}")
	public ResponseEntity<String> TransferMoney(@PathVariable String mobileno1,@PathVariable String mobileno2,@PathVariable Integer amount){
		
		service.TransferMoney(mobileno1, mobileno2, amount);
		return new ResponseEntity<String>("Transfer MOney Done", HttpStatus.OK);
		
		
	}
	
	@GetMapping(value= "/getall")
	public List<Account> GetAllAccounts(){
		 return service.getAllAccounts();
		
	}
}

 package com.cg.walletProject.entities;

import java.io.Serializable;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;


@Entity
@Table(name="wallets")
@XmlRootElement
public class Account implements Serializable{

	@Id
	@Column(name="mobileno",length=10)
	private String mobileno;
	
	@Column(name="custmername", length=30)
	private String custmername;
	
	@Column(name="accno", length=30)
	private Integer accno;
	
	@Column(name="balance", length=30)
	private double  balance;

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getCustmername() {
		return custmername;
	}

	public void setCustmername(String custmername) {
		this.custmername = custmername;
	}

	public Integer getAccno() {
		return accno;
	}

	public void setAccno(Integer accno) {
		this.accno = accno;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	
	
}

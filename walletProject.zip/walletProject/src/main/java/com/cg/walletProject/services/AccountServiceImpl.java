package com.cg.walletProject.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.walletProject.Exception.ApplicationException;
import com.cg.walletProject.dao.AccountDao;
import com.cg.walletProject.entities.Account;
@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	private AccountDao dao;
	
	@Transactional
	public void create(Account ac) {
		
		dao.save(ac);
		
	}

	@Transactional
	public Account search(String mobileno) {
		
		return dao.findById(mobileno).get();
		
		
	}

	@Transactional
	public void delete(String mobileno) {
	
		if(mobileno!=null) 
		dao.deleteById(mobileno);
	}

	@Transactional
	public String addMoney(Integer amount,String mobileno) throws ApplicationException {
		// TODO Auto-generated method stub
		String s ="Amount added Succesfully";
		if(mobileno!=null) {
		Account ac=search(mobileno);
		double bal=ac.getBalance() + amount;
		 ac.setBalance(bal);
		 System.out.println("New Balance is" +ac.getBalance());
		dao.save(ac);
		}
		else
			throw new ApplicationException("Please Check your Mobileno.");
		
		return s;
	}

	@Transactional
	public String TransferMoney(String mobileno1, String mobileno2,Integer amount) throws ApplicationException {
		// TODO Auto-generated method stub
		
		String s="Transfer done Succesfully";
		if(mobileno1!=null && mobileno2!=null) {
		Account ac1=search(mobileno1);
		Account ac2=search(mobileno2);
		double bal2= ac2.getBalance()+amount;
		 double bal1=ac1.getBalance()-amount;
		 ac1.setBalance(bal1);
		 ac2.setBalance(bal2);
		 dao.save(ac1);
		 dao.save(ac2);
		}
		else {
			throw new ApplicationException("Please check MobileNO.");
		}
		
		
		return s;
	}
	@Transactional
	public List<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Transactional
	public void WithDraw(String mobileno1,  Integer amount) throws ApplicationException{
		// TODO Auto-generated method stub
		
		
		if(mobileno1!=null) {
			Account ac=search(mobileno1);
		double bal=ac.getBalance() - amount;
		 ac.setBalance(bal);
		 System.out.println("New Balance is" +ac.getBalance());
		dao.save(ac);
		}
		else
			 throw new ApplicationException("Please Check your Mobileno.");
		
		
	}

	
	
}

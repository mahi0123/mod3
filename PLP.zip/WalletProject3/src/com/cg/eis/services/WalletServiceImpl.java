package com.cg.eis.services;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.eis.Bean.Account;
import com.cg.eis.dao.AccountDAO;
import com.cg.eis.dao.AccountDaoImpl;
import com.cg.eis.exception.WalletException;

public class WalletServiceImpl implements WalletService {
/*
 * WalletService is connecting to AccountDAO
 * */
	AccountDAO accountdao=new AccountDaoImpl();
	@Override
	public boolean validateMobile(String mobile) {

		boolean m=false;
		m=mobile.matches(mobilePattern);
		
		return m;
	}

	@Override
	public boolean createAccount(Account ac) {
		// TODO Auto-generated method stub
		
		return accountdao.createAccount(ac);
	}

	@Override
	public Account getAccountBymobile(int mobileNo) throws WalletException {
		// TODO Auto-generated method stub
		return accountdao.getAccountBymobile(mobileNo);
	}

	@Override
	public Map<Integer, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return accountdao.getAllAccount();
	}

	@Override
	public double add(double amount, Account ac) {
		// TODO Auto-generated method stub
		
		ac.setBalance(ac.getBalance()+amount);
		return ac.getBalance();
	}

	@Override
	public Account updateAccount(Account ac) throws WalletException {
		// TODO Auto-generated method stub
		return accountdao.updateAccount(ac);
	}

	@Override
	public boolean delete(String mobileNumber) throws WalletException {
		// TODO Auto-generated method stub
		validateMobile(mobileNumber);
		return accountdao.delete(mobileNumber);
	}

	@Override
	public boolean transferMoney(Account ac1, Account ac2) {
		// TODO Auto-generated method stub
		return accountdao.transferMoney(ac1, ac2);
	}

	@Override
	public int accountNumber() {
		// TODO Auto-generated method stub
		int accountnumber=(int) (Math.random()*10000);
		if(accountnumber!=0)
		return accountnumber;
		else
			return 0;
	}

	@Override
	public boolean customerNameValidation(String name) {
		
		// TODO Auto-generated method stub
		//boolean cname=regex.matches(name);
		if (name!=null) {
			return true;
		}
		return false;
	}

	@Override
	public double balanceValidation(double bal) throws WalletException {
		// TODO Auto-generated method stub
		if(bal>=500)
		return bal;
		else
			throw new WalletException("Balance is greater than 500");
	}
	

}

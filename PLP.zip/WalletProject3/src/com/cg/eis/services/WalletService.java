package com.cg.eis.services;

import java.util.Map;

import com.cg.eis.Bean.Account;
import com.cg.eis.exception.WalletException;

public interface WalletService {
String mobilePattern="[6-9][0-9]{9}";//10digit pattern for mobile number
//String regex="^[A-Z]{3,}$";
public boolean validateMobile(String mobile);
public boolean createAccount(Account ac);
public double add(double amount,Account ac);
public Account updateAccount(Account ac) throws WalletException;
public boolean delete(String mobileNumber) throws WalletException;
public boolean transferMoney(Account ac1,Account ac2);
public Account getAccountBymobile(int mobileNo) throws WalletException;
public Map<Integer, Account>getAllAccount();
int accountNumber();
boolean customerNameValidation(String name);
double balanceValidation(double bal) throws WalletException;

}

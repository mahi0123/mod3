package com.cg.eis.pl;
import java.util.Map;
import java.util.Scanner;

import com.cg.eis.Bean.Account;
import com.cg.eis.exception.WalletException;
import com.cg.eis.services.*;
public class MyWallet {

	public static void main(String[] args) throws WalletException {
		// TODO Auto-generated method stub
		 int accountNumber;
		 String custerName;
		 int mobileNo;
		 double balance;
WalletService service=new WalletServiceImpl();
Scanner sc=new Scanner(System.in);
Account ac=new Account();
System.out.println("Choose the option \n 1 create Account \n 2 Deposit \n 3 delete \n 4 update Details"
		+ "\n 5 Transformoney \n 6 GetAccountDetails \n 7 Get All Account Details \n 8 exit");
int ch=sc.nextInt();
switch(ch) 
{
case 1:System.out.println("Your option is Create Account number");
System.out.println("Enter the Your Name");
boolean vname=false;
do {
String name=sc.next();
vname=service.customerNameValidation(name);
if(vname) {
	custerName=name;
	System.out.println(custerName);
}
else {
	System.out.println("enter your  name again");
	name=sc.next();
}

}
while(vname!=false);
break;
case 2:System.out.println("Enter Your Amount");
double amount=sc.nextDouble();
balance=service.add(amount, ac);
System.out.println("your balance is "+balance);
break;
case 3:System.out.println("Delete your Acooucnt by using mobile number");

if(service.delete(sc.next()))
	System.out.println("succefully deleted");
else {
	System.out.println("ur account not deleted");
}break;
case 4:System.out.println("");


}

/*Account ob1=new Account(100,"Rana",1234567890,25000); 
System.out.println(service.validateMobile("906584123"));
boolean added=service.createAccount(ob1);
System.out.println("account add  "+added);

Account ob2=new Account(101,"chai",11,30000);
added=service.createAccount(ob2);
System.out.println("account add  "+added);
Map<Integer, Account>allac=service.getAllAccount();
System.out.println(allac);
Account myac=service.getAccountBymobile(11);
System.out.println(myac);*/
	}

}

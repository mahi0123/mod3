package com.cg.eis.dao;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.cg.eis.Bean.Account;
import com.cg.eis.exception.WalletException;

public class AccountDaoImpl implements AccountDAO  {
//Wallet Account database
	
	Map<Integer, Account>walletAccounts=new ConcurrentHashMap<>();
/*
 * Method to insert new account in a database
 * 
 * */
@Override
	public boolean createAccount(Account ac) {
	walletAccounts.put(ac.getMobileNo(), ac);
	Account ac1=walletAccounts.get(ac.getMobileNo());
	if (ac1!=null) { 
		return true;
	}	
	return false;
	}

	/*
	 * method retrieve account by mobile number from database
	 * */
	@Override
	public Account getAccountBymobile(int mobileNo) throws WalletException {
		//
	Account ac=	walletAccounts.get(mobileNo);
		if(ac!=null)
		return ac;
		else 
		{
		throw new WalletException("Invalid Mobile Number");
		}
	}

	@Override
	public Map<Integer, Account> getAllAccount() {
		//=>getting all accounts in wallet 
		
		return walletAccounts;
	}

	

	@Override
	public double add(double amount, Account ac) {
		// TODO Auto-generated method stub
		double money=ac.getBalance()+amount;
		ac.setBalance(money);
		return ac.getBalance();
	}

	@Override
	public Account updateAccount(Account ac)throws WalletException {
		// TODO Auto-generated method stub
		walletAccounts.put(ac.getMobileNo(),ac);
		Account ac1=walletAccounts.get(ac.getMobileNo());
		if(ac1!=null)
		return ac1;
		else {
			throw new WalletException("invalid AccountNumber");
		}
	}

	@Override
	public boolean delete(String mobileNumber) throws WalletException {
		// TODO Auto-generated method stub
		Account ac=walletAccounts.remove(mobileNumber);
		if (ac==null) {
			return true;
		}
		
		throw new WalletException("Invalid Mobile Number");
	}

	@Override
	public boolean transferMoney(Account ac1, Account ac2) {
		// TODO Auto-generated method stub
		if(ac1!=null&&ac2!=null) {
			
		}
		
		return false;
	}

}

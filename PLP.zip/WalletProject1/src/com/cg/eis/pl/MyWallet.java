package com.cg.eis.pl;
import java.util.Map;

import com.cg.eis.Bean.Account;
import com.cg.eis.services.*;
public class MyWallet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
WalletService service=new WalletServiceImpl();

Account ob1=new Account(100,"Rana",1234567890,25000); 
System.out.println(service.validateMobile("906584123"));
boolean added=service.createAccount(ob1);
System.out.println("account add  "+added);

Account ob2=new Account(101,"chai",11,30000);
added=service.createAccount(ob2);
System.out.println("account add  "+added);
Map<Integer, Account>allac=service.getAllAccount();
System.out.println(allac);
Account myac=service.getAccountBymobile(11);
System.out.println(myac);
	}

}

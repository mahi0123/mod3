package com.cg.eis.Bean;

public class Account {
private int accountNumber;
private String custerName;
private int mobileNo;
private double balance;
public Account() {
	// TODO Auto-generated constructor stub
}
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public String getCusterName() {
	return custerName;
}
public void setCusterName(String custerName) {
	this.custerName = custerName;
}
public int getMobileNo() {
	return mobileNo;
}
public void setMobileNo(int mobileNo) {
	this.mobileNo = mobileNo;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public Account(int accountNumber, String custerName, int mobileNo, double balance) {
	super();
	this.accountNumber = accountNumber;
	this.custerName = custerName;
	this.mobileNo = mobileNo;
	this.balance = balance;
}
@Override
public String toString() {
	return "Account [accountNumber=" + accountNumber + ", custerName=" + custerName + ", mobileNo=" + mobileNo
			+ ", balance=" + balance + "]";
}

}

package com.cg.bootdemo1.controllers;

import java.util.LinkedList;
import java.util.List;



import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bootdemo1.entities.Product;

@RestController
public class ProductController {
	

	
	@GetMapping("/")
	public String sayHello() {
		return "Hello JAMESBOND";
	}
	@GetMapping("/all-products")
	public List<Product> products(){
		
		List<Product> ps=new LinkedList<>();
		Product p1=new Product();
		p1.setDescription("Sample PRoduct");
		p1.setName("CAr");
		p1.setPrice(10256233.2);
		p1.setProductId("2012");
		ps.add(p1);
		
		Product p2=new Product();
		p2.setDescription("Sample PRoduct");
		p2.setName("BIke");
		p2.setPrice(10256233.2);
		p2.setProductId("2015");
		ps.add(p2);
		return ps;
		
		
		
	}

}

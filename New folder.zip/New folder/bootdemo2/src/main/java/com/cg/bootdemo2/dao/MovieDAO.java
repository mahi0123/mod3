package com.cg.bootdemo2.dao;

import com.cg.bootdemo2.entities.Movie;

public interface MovieDAO {
	
	void save(Movie movie);
	Movie findById(Integer id);

}

package com.cg.restparams.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	
	
	@GetMapping("/hello")
	public String testParam
		(@RequestParam String name) {
		return "HEllo " +name;
	}
	
	@GetMapping("/say-hi-{name}")
	public String testPathVariable(@PathVariable String name) {
		
		return "AYe Aye Captain " +name;
	}
}

package com.cg.walletproject.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;



@XmlRootElement
@Entity
@Table(name="wacc")
public class Account {
private String name;
@Id
private String mobno;
private String accno;
public Account() {
	// TODO Auto-generated constructor stub
}
public Account(String name, String mobno, String accno) {
	super();
	this.name = name;
	this.mobno = mobno;
	this.accno = accno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMobno() {
	return mobno;
}
public void setMobno(String mobno) {
	this.mobno = mobno;
}
public String getAccno() {
	return accno;
}
public void setAccno(String accno) {
	this.accno = accno;
}
}

package com.cg.walletproject.services;

import com.cg.walletproject.entities.Account;

public interface AccountService {
public void createacoount(Account ac);
public void addmoney(double amount,Integer mobno);
public void transfermoney(double amount,Integer mobno1,Integer mobno2);
}

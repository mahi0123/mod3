package com.cg.walletproject.controllers;

public class WalletController {

}

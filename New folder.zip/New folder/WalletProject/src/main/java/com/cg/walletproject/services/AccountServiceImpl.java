package com.cg.walletproject.services;

import com.cg.walletproject.entities.Account;

public class AccountServiceImpl implements AccountService {

	@Override
	public void createacoount(Account ac) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addmoney(double amount, Integer mobno) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void transfermoney(double amount, Integer mobno1, Integer mobno2) {
		// TODO Auto-generated method stub
		
	}

}

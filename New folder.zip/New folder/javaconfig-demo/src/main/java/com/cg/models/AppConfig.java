package com.cg.models;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
@Configuration
public class AppConfig {
@Bean
@Scope("singleton")
public Department dept() {
Department d = new Department();
d.setName("HR");
return d;
}
@Bean
public Employee emp() {
	Employee e=  new Employee();
	e.setName("likhitha");
	e.setDepartment(dept());
	return e;
}
}

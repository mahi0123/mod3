package com.cg.models;

public class Department {
private String name;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

}

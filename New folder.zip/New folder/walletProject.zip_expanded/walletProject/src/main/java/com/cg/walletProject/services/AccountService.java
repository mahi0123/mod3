package com.cg.walletProject.services;

import java.util.List;

import com.cg.walletProject.entities.Account;

public interface AccountService {
  
	void create(Account ac);
	Account search(String mobileno);
	void delete(String mobileno) ;
	String addMoney(Integer amount, String mobileno) throws ApplicationException;
	String TransferMoney(String mobileno1, String mobileno2 ,Integer amount) throws ApplicationException;
	List<Account> getAllAccounts();
	void WithDraw(String mobileno1,Integer amount ) throws ApplicationException;
	double ShowBalance(String mobileno);
	
}

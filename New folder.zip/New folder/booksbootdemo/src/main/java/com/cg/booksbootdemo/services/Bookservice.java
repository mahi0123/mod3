package com.cg.booksbootdemo.services;

import java.util.List;

import com.cg.booksbootdemo.entities.Books;

public interface Bookservice {
	
	public List<Books> books();
	void save(Books books);
	Books findById(Integer id);

}

package com.cg.booksbootdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooksbootdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksbootdemoApplication.class, args);
	}

}

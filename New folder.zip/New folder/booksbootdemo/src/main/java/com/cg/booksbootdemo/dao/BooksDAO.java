package com.cg.booksbootdemo.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.booksbootdemo.entities.Books;

public interface BooksDAO {
	
	public List<Books> books();
	void save(Books books);
	Books findById(Integer id);
	

}

package com.cg.booksbootdemo.controllers;

import java.util.LinkedList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;

import com.cg.booksbootdemo.entities.Books;


public class BookController {
	
	@GetMapping("/all-books")
	public List<Books> books(){
	List<Books> bs=new LinkedList<>();
	Books b1=new Books();
	b1.setAuthor("Herione");
	b1.setGenre("Comedy");
	b1.setName("Fun And Frustration");
	b1.setPrice(120.3);
	return bs;
	}

}

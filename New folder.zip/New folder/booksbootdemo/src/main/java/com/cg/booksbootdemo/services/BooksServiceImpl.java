package com.cg.booksbootdemo.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Service;

import com.cg.booksbootdemo.entities.Books;

@Service
public class BooksServiceImpl implements Bookservice{
	
	private EntityManager em;
	List<Books> bs=new ArrayList<>();
	@Override
	public List<Books> books() {
		// TODO Auto-generated method stub
		
		return bs;
	}

	@Override
	public void save(Books books) {
		// TODO Auto-generated method stub
		
	bs.add(books);
		
	}

	@Override
	public Books findById(Integer id) {
		// TODO Auto-generated method stub
		return em.find(Books.class, id);
	}


}

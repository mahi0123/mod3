package com.cg.booksbootdemo.dao;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.booksbootdemo.entities.Books;

@Repository
public class BooksDAOImpl implements BooksDAO {
	
	private EntityManager em;

	
	List<Books> bs=new ArrayList<>();
	@Override
	public List<Books> books() {
		// TODO Auto-generated method stub
		
		return bs;
	}

	@Override
	public void save(Books books) {
		// TODO Auto-generated method stub
		
	bs.add(books);
		
	}

	@Override
	public Books findById(Integer id) {
		// TODO Auto-generated method stub
		return em.find(Books.class, id);
	}

}

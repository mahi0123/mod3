package com.capstore.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Table(name="Feedback")
public class Feedback {
@Id
@Column(name="feedbackId")
@GeneratedValue(strategy=GenerationType.AUTO)
private int feedbackId;

//@Column(name="customerId")
@OneToOne(targetEntity=Customer.class)
private Customer customer;

	
//@Column(name="productId")
@OneToOne(targetEntity=Product.class)
private Product product;
	
@Column(name="ratingProduct")
	
private double ratingProduct;
	
@Column(name="ratingMerchant")
	
private double ratingMerchant;
	
@Column(name="comment")

private String comment;
//@Column(name="merchantId")
@OneToOne(targetEntity=Merchant.class)
private Merchant merchant;



public int getFeedbackId() {
	return feedbackId;
}

public void setFeedbackId(int feedbackId) {
	this.feedbackId = feedbackId;
}

public double getRatingProduct() {
	return ratingProduct;
}

public void setRatingProduct(double ratingProduct) {
	this.ratingProduct = ratingProduct;
}

public double getRatingMerchant() {
	return ratingMerchant;
}

public void setRatingMerchant(double ratingMerchant) {
	this.ratingMerchant = ratingMerchant;
}

public String getComment() {
	return comment;
}

public void setComment(String comment) {
	this.comment = comment;
}

public Customer getCustomer() {
	return customer;
}

public void setCustomer(Customer customer) {
	this.customer = customer;
}

public Product getProduct() {
	return product;
}

public void setProduct(Product product) {
	this.product = product;
}

public Merchant getMerchant() {
	return merchant;
}

public void setMerchant(Merchant merchant) {
	this.merchant = merchant;
}

@Override
public String toString() {
	return "Feedback [feedbackId=" + feedbackId + ", customer=" + customer + ", product=" + product + ", ratingProduct="
			+ ratingProduct + ", ratingMerchant=" + ratingMerchant + ", comment=" + comment + ", merchant=" + merchant
			+ "]";
}
public Feedback() {
	// TODO Auto-generated constructor stub
}

public Feedback(int feedbackId, Customer customer, Product product, double ratingProduct, double ratingMerchant,
		String comment, Merchant merchant) {
	super();
	this.feedbackId = feedbackId;
	this.customer = customer;
	this.product = product;
	this.ratingProduct = ratingProduct;
	this.ratingMerchant = ratingMerchant;
	this.comment = comment;
	this.merchant = merchant;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((comment == null) ? 0 : comment.hashCode());
	result = prime * result + ((customer == null) ? 0 : customer.hashCode());
	result = prime * result + feedbackId;
	result = prime * result + ((merchant == null) ? 0 : merchant.hashCode());
	result = prime * result + ((product == null) ? 0 : product.hashCode());
	long temp;
	temp = Double.doubleToLongBits(ratingMerchant);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	temp = Double.doubleToLongBits(ratingProduct);
	result = prime * result + (int) (temp ^ (temp >>> 32));
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Feedback other = (Feedback) obj;
	if (comment == null) {
		if (other.comment != null)
			return false;
	} else if (!comment.equals(other.comment))
		return false;
	if (customer == null) {
		if (other.customer != null)
			return false;
	} else if (!customer.equals(other.customer))
		return false;
	if (feedbackId != other.feedbackId)
		return false;
	if (merchant == null) {
		if (other.merchant != null)
			return false;
	} else if (!merchant.equals(other.merchant))
		return false;
	if (product == null) {
		if (other.product != null)
			return false;
	} else if (!product.equals(other.product))
		return false;
	if (Double.doubleToLongBits(ratingMerchant) != Double.doubleToLongBits(other.ratingMerchant))
		return false;
	if (Double.doubleToLongBits(ratingProduct) != Double.doubleToLongBits(other.ratingProduct))
		return false;
	return true;
}


	




	
}
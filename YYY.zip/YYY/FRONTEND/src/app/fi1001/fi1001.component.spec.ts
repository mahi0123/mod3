import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Fi1001Component } from './fi1001.component';

describe('Fi1001Component', () => {
  let component: Fi1001Component;
  let fixture: ComponentFixture<Fi1001Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Fi1001Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Fi1001Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

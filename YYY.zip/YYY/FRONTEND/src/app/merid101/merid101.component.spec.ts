import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Merid101Component } from './merid101.component';

describe('Merid101Component', () => {
  let component: Merid101Component;
  let fixture: ComponentFixture<Merid101Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Merid101Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Merid101Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

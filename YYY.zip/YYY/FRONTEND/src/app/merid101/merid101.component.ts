import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '../../../node_modules/@angular/router';
import { UserService } from '../service/user.service';
import { User } from '../model/rating.model';
@Component({
  selector: 'app-merid101',
  templateUrl: './merid101.component.html',
  styleUrls: ['./merid101.component.css']
})
export class Merid101Component implements OnInit {
  user:User;
  constructor(private router:Router,private userService:UserService) { }

  ngOnInit() {
    this.userService.getMerchantRating(101)

    .subscribe(data=>{ 
      //subscribe method observes all the changes and update teh changes
  
    //this.products = this.products.filter(u=> u!==product);
  
    this.user=data
  
     });
  }

}

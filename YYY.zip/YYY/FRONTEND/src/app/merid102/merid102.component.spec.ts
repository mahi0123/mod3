import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Merid102Component } from './merid102.component';

describe('Merid102Component', () => {
  let component: Merid102Component;
  let fixture: ComponentFixture<Merid102Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Merid102Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Merid102Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

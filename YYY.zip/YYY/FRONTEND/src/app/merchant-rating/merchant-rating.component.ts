import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-rating',
  templateUrl: './merchant-rating.component.html',
  styleUrls: ['./merchant-rating.component.css']
})
export class MerchantRatingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

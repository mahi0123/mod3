import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantRatingComponent } from './merchant-rating.component';

describe('MerchantRatingComponent', () => {
  let component: MerchantRatingComponent;
  let fixture: ComponentFixture<MerchantRatingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantRatingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantRatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

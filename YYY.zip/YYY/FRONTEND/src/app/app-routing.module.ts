import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RatingComponent } from './rating/rating.component';
import { Fi1001Component } from './fi1001/fi1001.component';
import { Fi1002Component } from './fi1002/fi1002.component';

import { MerchantRatingComponent } from './merchant-rating/merchant-rating.component';
import { Merid101Component } from './merid101/merid101.component';
import { Merid102Component } from './merid102/merid102.component';


const routes: Routes = [
  // {path:'login',component:LoginComponent},
  {path:'home',component:HomeComponent},
  {path:'rating',component:RatingComponent},
  {path:'merchant-rating',component:MerchantRatingComponent},
  {path:'fi1011',component:Fi1001Component},
   {path:'fi1012',component:Fi1002Component},
   {path:'merid101',component:Merid101Component},
   {path:'merid102',component:Merid102Component},
  
  // {path:'edit-user',component:EditUserComponent},
  // {path:'edit-user/:id',component:EditUserComponent},
  // {path:'',component: HomeComponent},
  //or
  //{path:'',redirectTo:'/home',pathMatch:'full'},
  // {path:'**',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

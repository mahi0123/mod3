import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  withdrawForm: FormGroup;
  submitted: boolean = false;
  invalid: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router) {}
  onSubmit() {
    this.submitted = true;
    if (this.withdrawForm.invalid) {
      return;
    }
  }

  ngOnInit() 
  {
    this.withdrawForm=this.formBuilder.group({accountnumber:['',Validators.required],
    Amount:['',Validators.required]});
  }

}

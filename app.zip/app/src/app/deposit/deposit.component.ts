import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  depositForm: FormGroup;
  submitted: boolean = false;
  invalid: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router) {}
  onSubmit() {
    this.submitted = true;
    if (this.depositForm.invalid) {
      return;
    }
  }

  ngOnInit() 
  {
    this.depositForm=this.formBuilder.group({accountnumber:['',Validators.required],
    Amount:['',Validators.required]});
  }

}

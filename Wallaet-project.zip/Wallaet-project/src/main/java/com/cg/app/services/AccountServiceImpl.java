package com.cg.app.services;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.app.Dao.AccountDao;
import com.cg.app.entities.Account;

@Service
public class AccountServiceImpl implements AccountService {
@Autowired
private AccountDao dao;

@Override
public void createAccount(Account ac) {
dao.createAccount(ac);
	
}

@Override
public void updateAccount(String mobileNo) {
	dao.updateAccount(mobileNo);
}

@Override
public void deleteAccount(String mobileNo) {
dao.deleteAccount(mobileNo);
	
}

@Override
public Account getAccounyByMobile(String mobileNo) {
	
	return dao.getAccounyByMobile(mobileNo);
}

@Override
public void transferMoney(Account ac1, Account ac2) {
	dao.transferMoney(ac1, ac2);
	
}

@Override
public void addMoney(Account ac) {
dao.addMoney(ac);
	
}

@Override
public Map<String, Account> getAllAccounts() {
	
	return dao.getAllAccounts();
}
	
}

package com.cg.app.services;

import java.util.Map;

import com.cg.app.entities.Account;

public interface AccountService {
	
	void createAccount(Account ac);
void updateAccount(String mobileNo);
void deleteAccount(String mobileNo);
Account getAccounyByMobile(String mobileNo);
void transferMoney(Account ac1,Account ac2);
void addMoney(Account ac);
Map<String,Account> getAllAccounts();


}

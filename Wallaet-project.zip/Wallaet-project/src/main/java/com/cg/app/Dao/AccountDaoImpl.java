package com.cg.app.Dao;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.print.attribute.HashAttributeSet;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cg.app.entities.Account;
import com.cg.app.exception.ApplicationException;
@Repository
public class AccountDaoImpl implements AccountDao {
	private Map<String,Account> acctdata=new HashMap<>();
	@PostConstruct
	public void intiAcctData() {
		acctdata.put("9701650946",new Account(200,"9701650946", "Venkatesh", 10000.0));
		acctdata.put("9701650945",new Account(201,"9701650945", "Venu", 20000.0));
		acctdata.put("9701650944",new Account(202,"9701650944", "Jaggu", 25000.0));
		acctdata.put("9701650943",new Account(203,"9701650943", "Prasanth", 30000.0));
	}

	@Override
	public void createAccount(Account ac) {
		boolean a=true;
if(acctdata.containsKey(ac.getMobileNo())){
	throw new ApplicationException("Account already exixts");
	
}
acctdata.put(ac.getMobileNo(),ac);
	}

	@Override
	public void updateAccount(String mobileNo) {
		
	
	
	}

	@Override
	public void deleteAccount(String mobileNo) {
	

	}

	@Override
	public Account getAccounyByMobile(String mobileNo) {
		Account ac=acctdata.get(mobileNo);
				if(ac==null) {
					throw new ApplicationException("Account not found!");
				}
		System.out.println(ac.getCustName() + " "+ac.getMobileNo());
		return ac;
	}

	@Override
	public void transferMoney(Account ac1, Account ac2) {
		

	}

	@Override
	public void addMoney(Account ac) {
		
	
	}

	@Override
	public Map<String, Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

}

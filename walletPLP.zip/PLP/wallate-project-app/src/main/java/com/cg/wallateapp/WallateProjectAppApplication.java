package com.cg.wallateapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WallateProjectAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WallateProjectAppApplication.class, args);
	}

}

package com.cg.wallateapp.dao;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Repository;


import com.cg.wallateapp.entities.Account;
import com.cg.wallateapp.exception.WalletException;
@Repository
public class AcoountDaoImpl implements AccountDao {
	private Map<Integer,Account >accontData=new HashMap<>();
	@PostConstruct
	public void initSampleData() {
		System.out.println("preparing sample data");
		accontData.put(1001, new Account(1001,"venky",829716,12000d));
		accontData.put(1002, new Account(1002,"priyanka",65416,13000d));
		accontData.put(1003, new Account(1003,"swathi",97816,14000d));
		accontData.put(1004, new Account(1004,"servesh",123716,15000d));
	}
	@Override
	public boolean createAccount(Account ac) 
	{
		if(accontData.containsKey(ac.getAccountNumber())) {
			throw new WalletException("already exits");}
	accontData.put(ac.getAccountNumber(), ac);
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Account getAccountBymobile(Integer acno) throws WalletException {
		// TODO Auto-generated method stub
		Account ac=accontData.get(acno);
		if (ac!=null) {
			return ac;
		}
		else {
			throw new WalletException("Account Not Found");
		}
		
	}
	@Override
	public Account updateAccount(Account ac) throws WalletException {
		// TODO Auto-generated method stub
		Account a=getAccountBymobile(ac.getAccountNumber());
	Account ac1=	accontData.put(ac.getAccountNumber(), ac);
	if(ac1!=null)
		return ac;
	else
		return null;
	}

	@Override
	public boolean delete(Integer acNO) throws WalletException {
		// TODO Auto-generated method stub
		Account ac=getAccountBymobile(acNO);
		accontData.remove(acNO);
		if(ac!=null)
		return true;
		return false;
	}
	@Override
	public double add(double amount, Account ac) {
		// TODO Auto-generated method stub
		Account a=getAccountBymobile(ac.getAccountNumber());
		ac.setBalance(a.getBalance()+amount);
		return ac.getBalance();
	}
	/*@Override
	public boolean transferMoney(Account ac1, Account ac2) {
		// TODO Auto-generated method stub
		return false;
	}*/
	/*@Override
	public Map<Integer, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return accontData;
	}*/
	

	

	
	

}

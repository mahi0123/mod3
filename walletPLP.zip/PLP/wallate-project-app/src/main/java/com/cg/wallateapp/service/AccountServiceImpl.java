package com.cg.wallateapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.wallateapp.dao.AccountDao;
import com.cg.wallateapp.entities.Account;
import com.cg.wallateapp.exception.WalletException;
@Service
public class AccountServiceImpl implements AccountService {
@Autowired private AccountDao dao;
	@Override
	public boolean createAccount(Account ac) {
		// TODO Auto-generated method stub
		return dao.createAccount(ac);
	}

	@Override
	public Account updateAccount(Account ac) throws WalletException {
		// TODO Auto-generated method stub
		return dao.updateAccount(ac);
	}

	@Override
	public boolean delete(Integer mobileNumber) throws WalletException {
		// TODO Auto-generated method stub
		return dao.delete(mobileNumber);
	}

	@Override
	public Account getAccountBymobile(Integer mobileNo) throws WalletException {
		// TODO Auto-generated method stub
		return dao.getAccountBymobile(mobileNo);
	}

	@Override
	public double add(double amount, Account ac) {
		// TODO Auto-generated method stub
		return dao.add(amount, ac);
	}

	//@Override
	/*public Map<Integer, Account> getAllAccount() {
		// TODO Auto-generated method stub
		return dao.getAllAccount();
	}
*/
}

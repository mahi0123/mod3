package com.cg.wallateapp.dao;

import java.util.Map;

import com.cg.wallateapp.entities.Account;
import com.cg.wallateapp.exception.WalletException;

public interface AccountDao {

	public boolean createAccount(Account ac);
	public double add(double amount,Account ac);
	public Account updateAccount(Account ac)throws WalletException;
	public boolean delete(Integer mobileNumber) throws WalletException;
	//public boolean transferMoney(Account ac1,Account ac2);
	public Account getAccountBymobile(Integer mobileNo) throws WalletException;
	//public Map<Integer, Account>getAllAccount();
}

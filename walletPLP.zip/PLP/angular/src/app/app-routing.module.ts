import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { CreateAccountComponent } from "./create-account/create-account.component";
import { ShowBalanceComponent } from "./show-balance/show-balance.component";
import { DepositComponent } from "./deposit/deposit.component";
import { WithdrawComponent } from "./withdraw/withdraw.component";
import { PrintTransactionsComponent } from "./print-transactions/print-transactions.component";
import { FundTransferComponent } from "./fund-transfer/fund-transfer.component";

const routes: Routes = [
  { path: "home", component: HomeComponent },
  { path: "create-account", component: CreateAccountComponent },
  { path: "show-balance", component: ShowBalanceComponent },
  { path: "deposit", component: DepositComponent },
  { path: "withdraw", component: WithdrawComponent },
  { path: "print-transactions", component: PrintTransactionsComponent },
  { path: "fund-transfer", component: FundTransferComponent },
  {path:'**',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}

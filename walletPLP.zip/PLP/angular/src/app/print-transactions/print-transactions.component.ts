import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-print-transactions',
  templateUrl: './print-transactions.component.html',
  styleUrls: ['./print-transactions.component.css']
})
export class PrintTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

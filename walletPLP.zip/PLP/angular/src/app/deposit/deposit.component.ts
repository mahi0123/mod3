import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AccountService } from '../service/account.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  depositForm: FormGroup;
  submitted: boolean = false;
  invalid: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router,private accountservice:AccountService) {}
  onSubmit() {
    this.submitted = true;
    if (this.depositForm.invalid) {
      return;
    }
    console.log(this.depositForm.value);
      this.accountservice.updateaccount(this.depositForm.value).subscribe(data=>{
        alert(this.depositForm.controls.firstname.value +'money deposited successfully')
        //alert(this.depositForm.controls.f//value+'record is added successfully')
        this.router.navigate(['home'])
      });
  }

  ngOnInit() 
  {
    this.depositForm=this.formBuilder.group({accountnumber:['',Validators.required],
    Amount:['',Validators.required]});
  }

}

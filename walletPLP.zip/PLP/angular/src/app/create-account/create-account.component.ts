import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { AccountService } from '../service/account.service';

@Component({
  selector: "app-create-account",
  templateUrl: "./create-account.component.html",
  styleUrls: ["./create-account.component.css"]
})
export class CreateAccountComponent implements OnInit {
  CreateForm: FormGroup;
  submitted: boolean = false;
  invalid: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router,private accountservice:AccountService ) {}
  onSubmit() {
    this.submitted = true;
    if (this.CreateForm.invalid) {
      return;
    }
    console.log(this.CreateForm.value);
      this.accountservice.createaccount(this.CreateForm.value).subscribe(data=>{
        alert(this.CreateForm.controls.firstname.value +' account created successfully')
        //alert(this.CreateForm.controls.f//value+'record is added successfully')
        this.router.navigate(['home'])
      });
  }
  ngOnInit() {
    this.CreateForm = this.formBuilder.group({
      firstname: ['', [Validators.required,Validators.pattern("[a-zA-Z]{5,30}")]],
      lastname: ['',Validators.compose( [Validators.required,Validators.pattern("[a-zA-Z]{5,30}")])],
      email: ['', Validators.required],
      mobilenumber:['',[Validators.required,Validators.pattern("[6-9][0-9]{9}")]],
      adrress: ['', Validators.required]
    });
  }
  
}

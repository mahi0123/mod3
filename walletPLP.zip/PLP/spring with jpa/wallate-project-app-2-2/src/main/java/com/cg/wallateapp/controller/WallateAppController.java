package com.cg.wallateapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.wallateapp.entities.Account;
import com.cg.wallateapp.service.AccountService;

@RestController
@RequestMapping("/accounts")
public class WallateAppController 
{
	@Autowired private AccountService service;
	@GetMapping (value="/{acno}")
	public Account search(@PathVariable Integer acno) 
	{ 
		return service.getAccountBymobile(acno);
		
	}
	@PostMapping(value="/createaccount")
	public ResponseEntity<String>create(@RequestBody Account ac){
		service.createAccount(ac);
		return  new ResponseEntity<String>("Record create",HttpStatus.CREATED);
	}
	@PutMapping(value="/updateaccount")
	public ResponseEntity<String>update(@RequestBody Account ac){
		service.createAccount(ac);
		return  new ResponseEntity<String>("Record updated",HttpStatus.OK);
	}
	@DeleteMapping(value="/delete")
	public ResponseEntity<String>delete(@RequestParam Integer acno)
	{
		service.delete(acno);
		return new ResponseEntity<String>("Record deleted",HttpStatus.OK);
		
	}
	@PutMapping(value="/deposit")
	public ResponseEntity<String>deposit(@RequestParam Integer mobilno,@RequestParam Double amount){
		service.add(amount,mobilno);
		return  new ResponseEntity<String>("amount deposited",HttpStatus.OK);
	}
	@PutMapping(value="/withdraw")
	public ResponseEntity<String>withdraw(@RequestParam Integer mobilno,@RequestParam Double amount){
		service.withdraw(amount, mobilno);
		return  new ResponseEntity<String>("withdraw amount successfull",HttpStatus.OK);
	}
	@PutMapping(value="/transfor")
	public ResponseEntity<String>transfor(@RequestParam Integer mob1 ,@RequestParam Integer mob2 , @RequestParam Double amount){
		service.transferMoney(mob1, mob2, amount);
		return  new ResponseEntity<String>("transfor amount successfull",HttpStatus.OK);
	}
	@GetMapping (value="/getall")
	public List<Account> getAll() 
	{ 
		return service.getAllAccounts();
		
	}

}

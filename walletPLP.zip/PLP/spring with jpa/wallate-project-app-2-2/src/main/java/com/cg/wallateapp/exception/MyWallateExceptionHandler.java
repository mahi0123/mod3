package com.cg.wallateapp.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class MyWallateExceptionHandler {
@ExceptionHandler(value=WalletException.class)
@ResponseBody
protected ResponseEntity<String>handleError(WalletException ex,HttpServletRequest req){
		String message=ex.getMessage();
		System.out.println("Caught Exception "+message);
		String url=req.getRequestURI().toString();
		System.out.println("Error At "+url);
		return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
	}
}

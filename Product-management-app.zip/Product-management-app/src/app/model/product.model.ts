export class Product{
    id: number;
    productname: string;
    price:number;
    quantity: number;
}
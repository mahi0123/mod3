import { Component } from '@angular/core';

@Component({

/*
[app-root] -> matches attribute
/app-root->matches class
<app-root>->matches element
*/
  //selector: '.app-root',   //using component as class  
  selector: 'app-root',    //using component as element
  //selector: '[app-root]',    //using component as attribute
  templateUrl: './app.component.html',
  //template: `<h1>welcome to My App..</h1>
  //<hr/>
  //'<h2>this is root component</h2>`
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Product Management System';
  developer= 'shruti';
  todaysDate = new Date();
}
